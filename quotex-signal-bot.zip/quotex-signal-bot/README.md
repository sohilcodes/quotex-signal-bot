# 🤖 Quotex Signal Bot

**TradingView → Webhook → Telegram Alert + Quotex Auto-Trade**

## 📁 Project Structure

```
quotex-signal-bot/
├── main.py                    # FastAPI server (webhook receiver)
├── telegram_bot.py            # Telegram alert sender
├── quotex_trader.py           # Quotex auto-trader
├── models.py                  # Data models
├── requirements.txt           # Python dependencies
├── render.yaml                # Render deployment config
├── tradingview_strategy.pine  # TradingView Pine Script
└── .env.example               # Environment variables template
```

---

## 🚀 Setup Guide

### Step 1: Telegram Bot Banao

1. Telegram pe [@BotFather](https://t.me/BotFather) open karo
2. `/newbot` type karo
3. Name aur username do (e.g. `QuotexSignalBot`)
4. **Bot Token** copy karo → `.env` mein `TELEGRAM_BOT_TOKEN` mein daalo

5. Apna **Chat ID** pane ke liye:
   - [@userinfobot](https://t.me/userinfobot) pe message bhejo
   - Ya channel banao aur bot ko admin banao
   - `TELEGRAM_CHAT_ID` mein daalo

---

### Step 2: Environment Setup

```bash
cp .env.example .env
# Ab .env file edit karo apni details ke saath
```

```env
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHI...
TELEGRAM_CHAT_ID=-100123456789
QUOTEX_EMAIL=youremail@gmail.com
QUOTEX_PASSWORD=yourpassword
DEFAULT_TRADE_AMOUNT=1
DEMO_MODE=true
WEBHOOK_SECRET=mysecretkey123
```

---

### Step 3: Local Test Karo

```bash
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Test webhook:
```bash
curl -X POST http://localhost:8000/webhook \
  -H "Content-Type: application/json" \
  -H "X-Webhook-Secret: mysecretkey123" \
  -d '{"asset":"EURUSD","direction":"call","duration":60,"amount":1}'
```

---

### Step 4: Render pe Deploy Karo

1. [render.com](https://render.com) pe account banao
2. **New → Web Service** click karo
3. GitHub repo connect karo
4. Environment variables add karo (`.env` se copy karo)
5. Deploy karo → tumhe ek URL milega jaise:
   `https://quotex-signal-bot.onrender.com`

---

### Step 5: TradingView Alert Setup

1. TradingView open karo
2. **Pine Editor** mein `tradingview_strategy.pine` paste karo
3. **Add to Chart** click karo
4. **Alert** create karo:
   - Condition: Strategy order fills
   - Webhook URL: `https://your-bot.onrender.com/webhook`
   - Custom Header add karo: `X-Webhook-Secret: mysecretkey123`
   - Message: (Pine Script se auto-generate hoga)

---

## 📊 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Bot status check |
| `/health` | GET | Health check |
| `/webhook` | POST | TradingView webhook |
| `/manual-trade` | POST | Manual trade trigger |

---

## ⚙️ Signal Format (Webhook JSON)

```json
{
  "asset": "EURUSD",
  "direction": "call",
  "duration": 60,
  "amount": 1.0,
  "strategy": "RSI+EMA",
  "confidence": "High",
  "price": "1.08234"
}
```

- `direction`: `"call"` (UP) ya `"put"` (DOWN)
- `duration`: seconds mein (60 = 1 minute)
- `amount`: USD mein trade amount

---

## ⚠️ Important Notes

- **Pehle DEMO mode mein test karo** (`DEMO_MODE=true`)
- Binary options mein risk hota hai — apne paison ka dhyan rakho
- `quotexapi` library unofficial hai, Quotex kabhi bhi block kar sakta hai
- Bot 24/7 active rahega Render pe (free tier pe sleep hota hai — paid plan lo)

---

## 🔧 Troubleshooting

**Quotex login fail ho raha hai?**
- 2FA disable karo Quotex account mein
- VPN use karo agar region block ho

**Telegram message nahi aa raha?**
- Bot ko channel mein admin banao
- Chat ID `-100` se start hona chahiye channels ke liye

**Render pe bot so jaata hai?**
- UptimeRobot se `/health` endpoint ping karo har 14 min mein
